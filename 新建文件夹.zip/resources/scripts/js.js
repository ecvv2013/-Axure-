javascript:
{$axure.utils.loadCSS('https://unpkg.com/element-ui/lib/theme-chalk/index.css');};
{$axure.utils.loadJS('https://unpkg.com/vue/dist/vue.js');};
{$axure.utils.loadJS('https://unpkg.com/element-ui@2.15.6/lib/index.js');};

